export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
export PEER0_ORG1_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/ca.crt
export PEER0_ORG2_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/ca.crt
export PEER0_ORG3_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/ca.crt
export FABRIC_CFG_PATH=${PWD}/artifacts/channel/config/

export CHANNEL_NAME=mychannel

setGlobalsForOrderer() {
    export CORE_PEER_LOCALMSPID="OrdererMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp

}

setGlobalsForPeer0UserOrg() {
    export CORE_PEER_LOCALMSPID="UserOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:7051
}

setGlobalsForPeer0InstOrg() {
    export CORE_PEER_LOCALMSPID="InstOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:9051

}

setGlobalsForPeer0ClientOrg(){
    export CORE_PEER_LOCALMSPID="ClientOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG3_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:11051
    
}

presetup() {
    echo Vendoring Go dependencies ...
    pushd ./artifacts/src/github.com/fabcar/go
    GO111MODULE=on go mod vendor
    popd
    echo Finished vendoring Go dependencies
}
# presetup

CHANNEL_NAME="mychannel"
CC_RUNTIME_LANGUAGE="golang"
VERSION="11"
SEQUENCE=9
CC_SRC_PATH="./artifacts/src/github.com/fabcar/go"
CC_NAME="fabcar"

packageChaincode() {
    rm -rf ${CC_NAME}.tar.gz
    setGlobalsForPeer0UserOrg
    peer lifecycle chaincode package ${CC_NAME}.tar.gz \
        --path ${CC_SRC_PATH} --lang ${CC_RUNTIME_LANGUAGE} \
        --label ${CC_NAME}_${VERSION}
    echo "===================== Chaincode is packaged ===================== "
}
# packageChaincode

installChaincode() {
    setGlobalsForPeer0UserOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer0.userOrg ===================== "

    setGlobalsForPeer0InstOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer0.instOrg ===================== "

    setGlobalsForPeer0ClientOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer0.clientOrg ===================== "
}

# installChaincode

queryInstalled() {
    setGlobalsForPeer0UserOrg
    peer lifecycle chaincode queryinstalled >&log.txt
    cat log.txt
    PACKAGE_ID=$(sed -n "/${CC_NAME}_${VERSION}/{s/^Package ID: //; s/, Label:.*$//; p;}" log.txt)
    echo PackageID is ${PACKAGE_ID}
    echo "===================== Query installed successful on peer0.userOrg on channel ===================== "
}

# queryInstalled

# --collections-config ./artifacts/private-data/collections_config.json \
#         --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member')" \

approveForMyUserOrg() {
    setGlobalsForPeer0UserOrg
    # set -x
    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls \
        --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
        --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} \
        --package-id ${PACKAGE_ID} \
        --sequence ${SEQUENCE}
    # set +x
    # --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \

    echo "===================== chaincode approved from org 1 ===================== "

}
# queryInstalled
# approveForMyUserOrg

# --signature-policy "OR ('UserOrgMSP.member')"
# --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA
# --peerAddresses peer0.userOrg.example.com:7051 --tlsRootCertFiles $PEER0_ORG1_CA --peerAddresses peer0.instOrg.example.com:9051 --tlsRootCertFiles $PEER0_ORG2_CA
#--channel-config-policy Channel/Application/Admins
# --signature-policy "OR ('UserOrgMSP.peer','InstOrgMSP.peer')"

checkCommitReadyness() {
    setGlobalsForPeer0UserOrg
    peer lifecycle chaincode checkcommitreadiness \
        --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} \
        --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
        --sequence ${SEQUENCE} --output json
    echo "===================== checking commit readyness from org 1 ===================== "
}
# --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
# checkCommitReadyness

approveForMyInstOrg() {
    setGlobalsForPeer0InstOrg

    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls $CORE_PEER_TLS_ENABLED \
        --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
        --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} \
        --version ${VERSION} --package-id ${PACKAGE_ID} \
        --sequence ${SEQUENCE}
# --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
    echo "===================== chaincode approved from org 2 ===================== "
}

# queryInstalled
# approveForMyInstOrg

checkCommitReadyness() {

    setGlobalsForPeer0InstOrg
    peer lifecycle chaincode checkcommitreadiness --channelID $CHANNEL_NAME \
        --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA \
        --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
        --name ${CC_NAME} --version ${VERSION} --sequence ${SEQUENCE} --output json
    echo "===================== checking commit readyness from org 1 ===================== "
}
# --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
# checkCommitReadyness

approveForMyClientOrg() {
    setGlobalsForPeer0ClientOrg

    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls $CORE_PEER_TLS_ENABLED \
        --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
        --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} \
        --version ${VERSION} --package-id ${PACKAGE_ID} \
        --sequence ${SEQUENCE}
# --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
    echo "===================== chaincode approved from org 2 ===================== "
}

# queryInstalled
# approveForMyClientOrg

checkCommitReadyness() {

    setGlobalsForPeer0ClientOrg
    peer lifecycle chaincode checkcommitreadiness --channelID $CHANNEL_NAME \
        --peerAddresses localhost:11051 --tlsRootCertFiles $PEER0_ORG3_CA \
        --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
        --name ${CC_NAME} --version ${VERSION} --sequence ${SEQUENCE} --output json
    echo "===================== checking commit readyness from org 1 ===================== "
}
# --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
# checkCommitReadyness

commitChaincodeDefination() {
    setGlobalsForPeer0UserOrg
    peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
        --channelID $CHANNEL_NAME --name ${CC_NAME} \
        --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA \
        --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA \
        --peerAddresses localhost:11051 --tlsRootCertFiles $PEER0_ORG3_CA \
        --version ${VERSION} --sequence ${SEQUENCE}
# --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member', 'ClientOrgMSP.member')" \
}

# commitChaincodeDefination

queryCommitted() {
    setGlobalsForPeer0UserOrg
    peer lifecycle chaincode querycommitted --channelID $CHANNEL_NAME --name ${CC_NAME}

}

# queryCommitted

chaincodeInvoke() {
    setGlobalsForPeer0UserOrg

    # Create Car
    peer chaincode invoke -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com \
        --tls $CORE_PEER_TLS_ENABLED \
        --cafile $ORDERER_CA \
        -C $CHANNEL_NAME -n ${CC_NAME}  \
        --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA \
        --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA   \
        -c '{"function": "createCar","Args":["{\"id\":\"2\",\"make\":\"Audi\",\"addedAt\":1600138309939,\"model\":\"R8\", \"color\":\"red\",\"owner\":\"pavan\"}"]}'

}

# chaincodeInvoke

chaincodeQuery() {
    setGlobalsForPeer0InstOrg
    peer chaincode query -C $CHANNEL_NAME -n ${CC_NAME} -c '{"function": "GetCarById","Args":["2"]}'
}

# chaincodeQuery

# Run this function if you add any new dependency in chaincode
presetup

packageChaincode
installChaincode
queryInstalled
approveForMyUserOrg
checkCommitReadyness
approveForMyInstOrg
checkCommitReadyness
approveForMyClientOrg
commitChaincodeDefination
queryCommitted
chaincodeInvokeInit
sleep 5
chaincodeInvoke
sleep 3
chaincodeQuery


