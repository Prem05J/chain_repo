# export CORE_PEER_TLS_ENABLED=true
# export ORDERER_CA=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
# export PEER0_ORG1_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/ca.crt
# export PEER0_ORG2_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/ca.crt
# export PEER0_ORG3_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/ca.crt
# export FABRIC_CFG_PATH=${PWD}/artifacts/channel/config/

# export CHANNEL_NAME=mychannel

export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
export PEER0_CLIENTORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/ca.crt
export PEER1_CLIENTORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/peers/peer1.clientOrg.example.com/tls/ca.crt
export PEER0_USERORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/ca.crt
export PEER1_USERORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/peers/peer1.userOrg.example.com/tls/ca.crt
export PEER0_INSTORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/ca.crt
export PEER1_INSTORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/peers/peer1.instOrg.example.com/tls/ca.crt
export FABRIC_CFG_PATH=${PWD}/artifacts/channel/config/


export INST_CLIENT_CHANNEL=instclientchannel
export USER_INST_CHANNEL=userinstchannel
export CLIENT_USER_CHANNEL=clientuserchannel
export CHANNEL_NAME=mychannel

# setGlobalsForPeer0UserOrg(){
#     export CORE_PEER_LOCALMSPID="UserOrgMSP"
#     export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
#     export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp
#     export CORE_PEER_ADDRESS=localhost:7051
# }

# setGlobalsForPeer0InstOrg(){
#     export CORE_PEER_LOCALMSPID="InstOrgMSP"
#     export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
#     export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp
#     export CORE_PEER_ADDRESS=localhost:9051
    
# }

# setGlobalsForPeer0ClientOrg(){
#     export CORE_PEER_LOCALMSPID="ClientOrgMSP"
#     export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG3_CA
#     export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp
#     export CORE_PEER_ADDRESS=localhost:11051
    
# }

setGlobalsForPeer0InstOrg(){
    export CORE_PEER_LOCALMSPID="InstOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_INSTORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:11051
    
}

setGlobalsForPeer1InstOrg(){
    export CORE_PEER_LOCALMSPID="InstOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_INSTORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:12051
    
}

setGlobalsForPeer0UserOrg(){
    export CORE_PEER_LOCALMSPID="UserOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_USERORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:9051
    
}

setGlobalsForPeer1UserOrg(){
    export CORE_PEER_LOCALMSPID="UserOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_USERORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:10051
    
}


setGlobalsForPeer0ClientOrg(){
    export CORE_PEER_LOCALMSPID="ClientOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_CLIENTORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:7051
}

setGlobalsForPeer1ClientOrg(){
    export CORE_PEER_LOCALMSPID="ClientOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_CLIENTORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:8051
}

createCLIENT_USER_CHANNEL(){
    # rm -rf ./channel-artifacts/*
    setGlobalsForPeer0ClientOrg
    
    peer channel create -o localhost:7050 -c $CLIENT_USER_CHANNEL \
    --ordererTLSHostnameOverride orderer.example.com \
    -f ./artifacts/channel/channels/${CLIENT_USER_CHANNEL}.tx --outputBlock ./channel-artifacts/${CLIENT_USER_CHANNEL}.block \
    --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
}

createUSER_INST_CHANNEL(){
    # rm -rf ./channel-artifacts/*
    setGlobalsForPeer0UserOrg
    
    peer channel create -o localhost:7050 -c $USER_INST_CHANNEL \
    --ordererTLSHostnameOverride orderer.example.com \
    -f ./artifacts/channel/channels/${USER_INST_CHANNEL}.tx --outputBlock ./channel-artifacts/${USER_INST_CHANNEL}.block \
    --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
}

createINST_CLIENT_CHANNEL(){
    # rm -rf ./channel-artifacts/*
    setGlobalsForPeer0InstOrg
    
    peer channel create -o localhost:7050 -c $INST_CLIENT_CHANNEL \
    --ordererTLSHostnameOverride orderer.example.com \
    -f ./artifacts/channel/channels/${INST_CLIENT_CHANNEL}.tx --outputBlock ./channel-artifacts/${INST_CLIENT_CHANNEL}.block \
    --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
}

removeOldCrypto(){
    rm -rf ./api-1.4/crypto/*
    rm -rf ./api-1.4/fabric-client-kv-userOrg/*
    rm -rf ./api-2.0/userOrg-wallet/*
    rm -rf ./api-2.0/instOrg-wallet/*
}

joinCLIENT_USER_CHANNEL(){
    setGlobalsForPeer0ClientOrg
    peer channel join -b ./channel-artifacts/$CLIENT_USER_CHANNEL.block
    
    setGlobalsForPeer1ClientOrg
    peer channel join -b ./channel-artifacts/$CLIENT_USER_CHANNEL.block
    
    setGlobalsForPeer0UserOrg
    peer channel join -b ./channel-artifacts/$CLIENT_USER_CHANNEL.block
    
    setGlobalsForPeer1UserOrg
    peer channel join -b ./channel-artifacts/$CLIENT_USER_CHANNEL.block
    
}

joinUSER_INST_CHANNEL(){
    setGlobalsForPeer0UserOrg
    peer channel join -b ./channel-artifacts/$USER_INST_CHANNEL.block
    
    setGlobalsForPeer1UserOrg
    peer channel join -b ./channel-artifacts/$USER_INST_CHANNEL.block
    
    setGlobalsForPeer0InstOrg
    peer channel join -b ./channel-artifacts/$USER_INST_CHANNEL.block
    
    setGlobalsForPeer1InstOrg
    peer channel join -b ./channel-artifacts/$USER_INST_CHANNEL.block
    
}

joinINST_CLIENT_CHANNEL(){
    setGlobalsForPeer0ClientOrg
    peer channel join -b ./channel-artifacts/$INST_CLIENT_CHANNEL.block
    
    setGlobalsForPeer1ClientOrg
    peer channel join -b ./channel-artifacts/$INST_CLIENT_CHANNEL.block
    
    setGlobalsForPeer0InstOrg
    peer channel join -b ./channel-artifacts/$INST_CLIENT_CHANNEL.block
    
    setGlobalsForPeer1InstOrg
    peer channel join -b ./channel-artifacts/$INST_CLIENT_CHANNEL.block
    
}



updateAnchorPeersforCLIENT_USER_CHANNEL(){
    setGlobalsForPeer1ClientOrg
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $CLIENT_USER_CHANNEL -f ./artifacts/channel/anchors/${CORE_PEER_LOCALMSPID}anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    
    setGlobalsForPeer1UserOrg
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $CLIENT_USER_CHANNEL -f ./artifacts/channel/anchors/${CORE_PEER_LOCALMSPID}1anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA

}

updateAnchorPeersforUSER_INST_CHANNEL(){
    setGlobalsForPeer1UserOrg
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $USER_INST_CHANNEL -f ./artifacts/channel/anchors/${CORE_PEER_LOCALMSPID}anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA

    setGlobalsForPeer1InstOrg
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $USER_INST_CHANNEL -f ./artifacts/channel/anchors/${CORE_PEER_LOCALMSPID}1anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    
}

updateAnchorPeersforINST_CLIENT_CHANNEL(){
    setGlobalsForPeer1ClientOrg
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $INST_CLIENT_CHANNEL -f ./artifacts/channel/anchors/${CORE_PEER_LOCALMSPID}1anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA

    setGlobalsForPeer1InstOrg
    peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $INST_CLIENT_CHANNEL -f ./artifacts/channel/anchors/${CORE_PEER_LOCALMSPID}anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    
}



# updateAnchorPeers(){
#     setGlobalsForPeer0UserOrg
#     peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $CHANNEL_NAME -f ./artifacts/channel/${CORE_PEER_LOCALMSPID}anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    
#     setGlobalsForPeer0InstOrg
#     peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $CHANNEL_NAME -f ./artifacts/channel/${CORE_PEER_LOCALMSPID}anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA

#     setGlobalsForPeer0ClientOrg
#     peer channel update -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com -c $CHANNEL_NAME -f ./artifacts/channel/${CORE_PEER_LOCALMSPID}anchors.tx --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA
    
# }

# removeOldCrypto
createCLIENT_USER_CHANNEL
createUSER_INST_CHANNEL
createINST_CLIENT_CHANNEL


joinCLIENT_USER_CHANNEL
joinUSER_INST_CHANNEL
joinINST_CLIENT_CHANNEL


updateAnchorPeersforCLIENT_USER_CHANNEL
updateAnchorPeersforUSER_INST_CHANNEL
updateAnchorPeersforINST_CLIENT_CHANNEL



# createChannel
# joinChannel
# updateAnchorPeers