package main

import (
	"encoding/json"
	"fmt"
	"strconv"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	sc "github.com/hyperledger/fabric-protos-go/peer"
	"github.com/hyperledger/fabric/common/flogging"
)

type SmartContract struct {
}

type UserProfile struct {
	UpID         string `json:"upId"`
	UserID       string `json:"userId"`
	FullName     string `json:"fullName"`
	BasicDetails string `json:"basicDetails"`
}

var logger = flogging.MustGetLogger("flanit")

func (s *SmartContract) Init(APIstub shim.ChaincodeStubInterface) sc.Response {
	return shim.Success(nil)
}

func (s *SmartContract) Invoke(APIstub shim.ChaincodeStubInterface) sc.Response {

	function, args := APIstub.GetFunctionAndParameters()
	logger.Infof("Function name is:  %d", function)
	logger.Infof("Args length is : %d", len(args))

	switch function {
	case "FetchUser":
		return s.FetchUser(APIstub, args)
	case "SaveUser":
		return s.SaveUser(APIstub, args)
	case "initLedger":
		return s.initLedger(APIstub)
	default:
		return shim.Error("Invalid Smart Contract function name.")
	}

	// return shim.Error("Invalid Smart Contract function name.")
}

func (s *SmartContract) initLedger(APIstub shim.ChaincodeStubInterface) sc.Response {
	userProfiles := []UserProfile{
		UserProfile{UpID: "1", UserID: "u001", FullName: "Tomoko", BasicDetails: "Owner of a blue Toyota Prius"},
		UserProfile{UpID: "2", UserID: "u002", FullName: "Brad", BasicDetails: "Owner of a red Ford Mustang"},
		UserProfile{UpID: "3", UserID: "u003", FullName: "Jin Soo", BasicDetails: "Owner of a green Hyundai Tucson"},
		UserProfile{UpID: "4", UserID: "u004", FullName: "Max", BasicDetails: "Owner of a yellow Volkswagen Passat"},
		UserProfile{UpID: "5", UserID: "u005", FullName: "Adriana", BasicDetails: "Owner of a black Tesla Model S"},
		UserProfile{UpID: "6", UserID: "u006", FullName: "Michel", BasicDetails: "Owner of a purple Peugeot 205"},
		UserProfile{UpID: "7", UserID: "u007", FullName: "Aarav", BasicDetails: "Owner of a white Chery S22L"},
		UserProfile{UpID: "8", UserID: "u008", FullName: "Pari", BasicDetails: "Owner of a violet Fiat Punto"},
		UserProfile{UpID: "9", UserID: "u009", FullName: "Valeria", BasicDetails: "Owner of an indigo Tata Nano"},
		UserProfile{UpID: "10", UserID: "u010", FullName: "Shotaro", BasicDetails: "Owner of a brown Holden Barina"},
	}

	i := 0
	for i < len(userProfiles) {
		carAsBytes, _ := json.Marshal(userProfiles[i])
		APIstub.PutState("User"+strconv.Itoa(i), carAsBytes)
		i = i + 1
	}

	return shim.Success(nil)
}

func (s *SmartContract) FetchUser(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {
	if len(args) != 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}
	carAsBytes, _ := APIstub.GetState(args[0])
	return shim.Success(carAsBytes)
}

func (s *SmartContract) SaveUser(APIstub shim.ChaincodeStubInterface, args []string) sc.Response {

	if len(args) != 5 {
		return shim.Error("Incorrect number of arguments. Expecting 5")
	}

	var user = UserProfile{UpID: args[1], UserID: args[2], FullName: args[3], BasicDetails: args[4]}

	userAsBytes, _ := json.Marshal(user)
	APIstub.PutState(args[0], userAsBytes)

	indexName := "owner~key"
	colorNameIndexKey, err := APIstub.CreateCompositeKey(indexName, []string{user.UserID, args[0]})
	if err != nil {
		return shim.Error(err.Error())
	}
	value := []byte{0x00}
	APIstub.PutState(colorNameIndexKey, value)

	return shim.Success(userAsBytes)
}

func main() {
	err := shim.Start(new(SmartContract))
	if err != nil {
		fmt.Printf("Error creating new Smart Contract: %s", err)
	}
}
