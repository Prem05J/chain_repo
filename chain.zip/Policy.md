Here are a few examples of valid principals:

    'Org0.admin': any administrator of the Org0 MSP
    'UserOrg.member': any member of the UserOrg MSP
    'UserOrg.client': any client of the UserOrg MSP
    'UserOrg.peer': any peer of the UserOrg MSP

Endorsement Policy Syntax

    AND('UserOrg.member', 'InstOrg.member', 'ClientOrg.member')
    OR('UserOrg.member', 'InstOrg.member')
    OR('UserOrg.member', AND('InstOrg.member', 'ClientOrg.member'))
    OutOf(1, 'UserOrg.member', 'InstOrg.member') -> OR('UserOrg.member', 'InstOrg.member')
    OutOf(2, 'UserOrg.member', 'InstOrg.member') -> AND('UserOrg.member', 'InstOrg.member')
    OutOf(2, 'UserOrg.member', 'InstOrg.member', 'ClientOrg.member')  -> OR(AND('UserOrg.member', 'InstOrg.member'), AND('UserOrg.member', 'ClientOrg.member'), AND('InstOrg.member', 'ClientOrg.member'))

collection-level endorsement policies

    {
        "name": "collectionMarblePrivateDetails",
        "policy": "OR('UserOrgMSP.member')",
        "requiredPeerCount": 0,
        "maxPeerCount": 3,
        "blockToLive":3,
        "memberOnlyRead": true,
        "memberOnlyWrite":true,
        "endorsementPolicy": {
        "signaturePolicy": "OR('UserOrgMSP.member')"
        }
    }

Key-level endorsement policies