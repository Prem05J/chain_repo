# export CORE_PEER_TLS_ENABLED=true
# export ORDERER_CA=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
# export PEER0_ORG1_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/ca.crt
# export PEER0_ORG2_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/ca.crt
# export PEER0_ORG3_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/ca.crt
# export FABRIC_CFG_PATH=${PWD}/artifacts/channel/config/

# export CHANNEL_NAME=mychannel

# setGlobalsForOrderer() {
#     export CORE_PEER_LOCALMSPID="OrdererMSP"
#     export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
#     export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp

# }

# setGlobalsForPeer0UserOrg() {
#     export CORE_PEER_LOCALMSPID="UserOrgMSP"
#     export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
#     export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp
#     export CORE_PEER_ADDRESS=localhost:7051
# }

# setGlobalsForUserOrg() {
#     export CORE_PEER_LOCALMSPID="UserOrgMSP"
#     export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG1_CA
#     export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/users/User1@userOrg.example.com/msp
#     export CORE_PEER_ADDRESS=localhost:7051
# }

# setGlobalsForPeer0InstOrg() {
#     export CORE_PEER_LOCALMSPID="InstOrgMSP"
#     export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG2_CA
#     export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp
#     export CORE_PEER_ADDRESS=localhost:9051

# }

# setGlobalsForPeer0ClientOrg(){
#     export CORE_PEER_LOCALMSPID="ClientOrgMSP"
#     export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_ORG3_CA
#     export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp
#     export CORE_PEER_ADDRESS=localhost:11051
    
# }


export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
export PEER0_CLIENTORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/ca.crt
export PEER0_USERORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/ca.crt
export PEER0_INSTORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/ca.crt
export PEER1_CLIENTORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/peers/peer1.clientOrg.example.com/tls/ca.crt
export PEER1_USERORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/peers/peer1.userOrg.example.com/tls/ca.crt
export PEER1_INSTORG_CA=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/peers/peer1.instOrg.example.com/tls/ca.crt
export FABRIC_CFG_PATH=${PWD}/artifacts/channel/config/


export PRIVATE_DATA_CONFIG_1=${PWD}/artifacts/private-data/collections_config_a.json
export PRIVATE_DATA_CONFIG_2=${PWD}/artifacts/private-data/collections_config_b.json
export PRIVATE_DATA_CONFIG_3=${PWD}/artifacts/private-data/collections_config_c.json

export CHANNEL_NAME=mychannel
export INST_CLIENT_CHANNEL=instclientchannel
export  USER_INST_CHANNEL=userinstchannel
export CLIENT_USER_CHANNEL=clientuserchannel

setGlobalsForOrderer() {
    export CORE_PEER_LOCALMSPID="OrdererMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp

}

setGlobalsForPeer0ClientOrg(){
    export CORE_PEER_LOCALMSPID="ClientOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_CLIENTORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:7051
}

setGlobalsForPeer1ClientOrg(){
    export CORE_PEER_LOCALMSPID="ClientOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_CLIENTORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:8051 
}

setGlobalsForPeer0UserOrg(){
    export CORE_PEER_LOCALMSPID="UserOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_USERORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:9051 
}

setGlobalsForPeer1UserOrg(){
    export CORE_PEER_LOCALMSPID="UserOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_USERORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:10051
}

setGlobalsForPeer0InstOrg(){
    export CORE_PEER_LOCALMSPID="InstOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER0_INSTORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:11051 
}

setGlobalsForPeer1InstOrg(){
    export CORE_PEER_LOCALMSPID="InstOrgMSP"
    export CORE_PEER_TLS_ROOTCERT_FILE=$PEER1_INSTORG_CA
    export CORE_PEER_MSPCONFIGPATH=${PWD}/artifacts/channel/crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp
    export CORE_PEER_ADDRESS=localhost:12051    
}


presetup() {
    echo Vendoring Go dependencies ...
    pushd "/home/dharitri/Documents/flanit/Smart Contract/flanitplus-sc" || exit 1
    GO111MODULE=on go mod tidy
    GO111MODULE=on go mod vendor
    popd || echo "Warning: popd failed (empty directory stack)"
    echo Finished vendoring Go dependencies
}
# presetup

# CHANNEL_NAME="mychannel"
# CC_RUNTIME_LANGUAGE="golang"
# VERSION="1"
# SEQUENCE=1
# CC_SRC_PATH="./artifacts/src/github.com/fabcar/go"
# CC_NAME="fabcar"

# CHANNEL_NAME="mychannel"
# INST_CLIENT_CHANNEL="instclientchannel"
# USER_INST_CHANNEL="userinstchannel"
# CLIENT_USER_CHANNEL="clientuserchannel"
# CC_RUNTIME_LANGUAGE="golang"
# VERSION="1"
# # CC_SRC_PATH="./artifacts/src/github.com/fabcar/go"
# CC_SRC_PATH="/home/dharitri/Documents/flanit/Smart Contract/flanitplus-sc"
# CC_NAME="flanitplus"

# packageChaincode() {
#     rm -rf ${CC_NAME}.tar.gz
#     setGlobalsForPeer0UserOrg
#     peer lifecycle chaincode package ${CC_NAME}.tar.gz \
#         --path ${CC_SRC_PATH} --lang ${CC_RUNTIME_LANGUAGE} \
#         --label ${CC_NAME}_${VERSION}
#     echo "===================== Chaincode is packaged ===================== "
# }


CHANNEL_NAME="mychannel"
INST_CLIENT_CHANNEL="instclientchannel"
USER_INST_CHANNEL="userinstchannel"
CLIENT_USER_CHANNEL="clientuserchannel"
CC_RUNTIME_LANGUAGE="golang"
VERSION="1"
CC_SRC_PATH="/home/dharitri/Documents/flanit/Smart Contract/userprofile-sc"
CC_NAME="userprofile"

packageChaincode() {
    echo "Removing old chaincode package if exists..."
    rm -f ${CC_NAME}.tar.gz

    echo "Setting globals for peer0.userorg..."
    setGlobalsForPeer0UserOrg

    echo "Packaging chaincode..."
    peer lifecycle chaincode package ${CC_NAME}.tar.gz \
        --path "${CC_SRC_PATH}" \
        --lang ${CC_RUNTIME_LANGUAGE} \
        --label ${CC_NAME}_${VERSION}

    if [ $? -eq 0 ]; then
        echo "===================== Chaincode is packaged ====================="
    else
        echo "Failed to package chaincode"
        exit 1
    fi
}


# packageChaincode

installChaincode() {
    setGlobalsForPeer0ClientOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer0.clientOrg ===================== "

    setGlobalsForPeer1ClientOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer1.clientOrg ===================== "

    setGlobalsForPeer0UserOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer0.userOrg ===================== "

    setGlobalsForPeer1UserOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer1.userOrg ===================== "

    setGlobalsForPeer0InstOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer0.instOrg ===================== "

    setGlobalsForPeer1InstOrg
    peer lifecycle chaincode install ${CC_NAME}.tar.gz
    echo "===================== Chaincode is installed on peer1.instOrg ===================== "
}

# installChaincode

queryInstalled() {
    setGlobalsForPeer1ClientOrg
    peer lifecycle chaincode queryinstalled >&log.txt
    cat log.txt
    PACKAGE_ID=$(sed -n "/${CC_NAME}_${VERSION}/{s/^Package ID: //; s/, Label:.*$//; p;}" log.txt)
    echo PackageID is ${PACKAGE_ID}
    echo "===================== Query installed successful on peer0.org1 on channel ===================== "

    setGlobalsForPeer1UserOrg
    peer lifecycle chaincode queryinstalled >&log.txt
    cat log.txt
    PACKAGE_ID=$(sed -n "/${CC_NAME}_${VERSION}/{s/^Package ID: //; s/, Label:.*$//; p;}" log.txt)
    echo PackageID is ${PACKAGE_ID}
    echo "===================== Query installed successful on peer0.org1 on channel ===================== "

    setGlobalsForPeer1InstOrg
    peer lifecycle chaincode queryinstalled >&log.txt
    cat log.txt
    PACKAGE_ID=$(sed -n "/${CC_NAME}_${VERSION}/{s/^Package ID: //; s/, Label:.*$//; p;}" log.txt)
    echo PackageID is ${PACKAGE_ID}
    echo "===================== Query installed successful on peer0.org1 on channel ===================== "
}

# queryInstalled

# --collections-config ./artifacts/private-data/collections_config.json \
#         --signature-policy "OR('UserOrgMSP.member','InstOrgMSP.member')" \

# approveForMyUserOrg() {
#     setGlobalsForPeer0UserOrg
#     # set -x
#     peer lifecycle chaincode approveformyorg -o localhost:7050 \
#         --ordererTLSHostnameOverride orderer.example.com --tls \
#         --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} \
#         --init-required --package-id ${PACKAGE_ID} \
#         --sequence ${SEQUENCE}
#     # set +x

#     echo "===================== chaincode approved from org 1 ===================== "
# }

approveForMyOrgforClientUserChannel() {
    setGlobalsForPeer1ClientOrg
    # set -x
    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls \
        --cafile $ORDERER_CA --channelID $CLIENT_USER_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --init-required --package-id ${PACKAGE_ID} \
        --sequence ${VERSION}


    setGlobalsForPeer1UserOrg
    # set -x
    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls \
        --cafile $ORDERER_CA --channelID $CLIENT_USER_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --init-required --package-id ${PACKAGE_ID} \
        --sequence ${VERSION}
    # set +x

    echo "===================== chaincode approved from org 1 ===================== "
}

approveForMyOrgforUserInstChannel() {
    setGlobalsForPeer1UserOrg
    # set -x
    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls \
        --cafile $ORDERER_CA --channelID $USER_INST_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --init-required --package-id ${PACKAGE_ID} \
        --sequence ${VERSION}



    setGlobalsForPeer1InstOrg
    # set -x
    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls \
        --cafile $ORDERER_CA --channelID $USER_INST_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --init-required --package-id ${PACKAGE_ID} \
        --sequence ${VERSION}
    # set +x

    echo "===================== chaincode approved from org 1 ===================== "


}

approveForMyOrgforInstClientChannel() {
    setGlobalsForPeer1ClientOrg
    # set -x
    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls \
        --cafile $ORDERER_CA --channelID $INST_CLIENT_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --init-required --package-id ${PACKAGE_ID} \
        --sequence ${VERSION}



    setGlobalsForPeer1InstOrg
    # set -x
    peer lifecycle chaincode approveformyorg -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com --tls \
        --cafile $ORDERER_CA --channelID $INST_CLIENT_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --init-required --package-id ${PACKAGE_ID} \
        --sequence ${VERSION}
    # set +x

    echo "===================== chaincode approved from org 1 ===================== "


}


# queryInstalled
# approveForMyOrgforClientUserChannel
# approveForMyOrgforUserInstChannel
# approveForMyOrgforInstClientChannel



# --signature-policy "OR ('UserOrgMSP.member')"
# --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA
# --peerAddresses peer0.userOrg.example.com:7051 --tlsRootCertFiles $PEER0_ORG1_CA --peerAddresses peer0.instOrg.example.com:9051 --tlsRootCertFiles $PEER0_ORG2_CA
# --channel-config-policy Channel/Application/Admins
# --signature-policy "OR ('UserOrgMSP.peer','InstOrgMSP.peer')"


# checkCommitReadyness() {
#     setGlobalsForPeer0UserOrg
#     peer lifecycle chaincode checkcommitreadiness \
#         --channelID $CHANNEL_NAME --name ${CC_NAME} --version ${VERSION} \
#         --sequence ${VERSION} --output json --init-required
#     echo "===================== checking commit readyness from org 1 ===================== "
# }

checkCommitReadyness() {
    setGlobalsForPeer1ClientOrg
    peer lifecycle chaincode checkcommitreadiness \
        --channelID $CLIENT_USER_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --sequence ${VERSION} --output json --init-required \
        --tlsRootCertFiles $PEER1_CLIENTORG_CA \
    echo "===================== checking commit readyness from org 1 ===================== "

    setGlobalsForPeer1UserOrg
    peer lifecycle chaincode checkcommitreadiness \
        --channelID $USER_INST_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --sequence ${VERSION} --output json --init-required \
        --tlsRootCertFiles $PEER1_USERORG_CA
        # --peerAddresses peer1.userOrg.example.com:10051 \
        
    echo "===================== checking commit readyness from org 1 ===================== "


    setGlobalsForPeer1InstOrg
    peer lifecycle chaincode checkcommitreadiness \
        --channelID $INST_CLIENT_CHANNEL --name ${CC_NAME} --version ${VERSION} \
        --sequence ${VERSION} --output json --init-required \
        --tlsRootCertFiles $PEER1_INSTORG_CA
    echo "===================== checking commit readyness from org 1 ===================== "

}

# checkCommitReadyness

# approveForMyInstOrg() {
#     setGlobalsForPeer0InstOrg

#     peer lifecycle chaincode approveformyorg -o localhost:7050 \
#         --ordererTLSHostnameOverride orderer.example.com --tls $CORE_PEER_TLS_ENABLED \
#         --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} \
#         --version ${VERSION} --init-required --package-id ${PACKAGE_ID} \
#         --sequence ${SEQUENCE}

#     echo "===================== chaincode approved from org 2 ===================== "
# }

# # queryInstalled
# # approveForMyInstOrg

# checkCommitReadyness() {

#     setGlobalsForPeer0InstOrg
#     peer lifecycle chaincode checkcommitreadiness
#     peer lifecycle chaincode checkcommitreadiness --channelID $CHANNEL_NAME \
#         --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA \
#         --name ${CC_NAME} --version ${VERSION} --sequence ${VERSION} --output json --init-required
#     echo "===================== checking commit readyness from org 1 ===================== "
# }

# # checkCommitReadyness

# approveForMyClientOrg() {
#     setGlobalsForPeer0ClientOrg

#     peer lifecycle chaincode approveformyorg -o localhost:7050 \
#         --ordererTLSHostnameOverride orderer.example.com --tls $CORE_PEER_TLS_ENABLED \
#         --cafile $ORDERER_CA --channelID $CHANNEL_NAME --name ${CC_NAME} \
#         --version ${VERSION} --init-required --package-id ${PACKAGE_ID} \
#         --sequence ${SEQUENCE}

#     echo "===================== chaincode approved from org 2 ===================== "
# }

# queryInstalled
# approveForMyClientOrg

# checkCommitReadyness() {

#     setGlobalsForPeer0ClientOrg
#     peer lifecycle chaincode checkcommitreadiness --channelID $CHANNEL_NAME \
#         --peerAddresses localhost:11051 --tlsRootCertFiles $PEER0_ORG3_CA \
#         --name ${CC_NAME} --version ${VERSION} --sequence ${VERSION} --output json --init-required
#     echo "===================== checking commit readyness from org 1 ===================== "
# }

# checkCommitReadyness

# commitChaincodeDefination() {
#     setGlobalsForPeer0UserOrg
#     peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com \
#         --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
#         --channelID $CHANNEL_NAME --name ${CC_NAME} \
#         --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA \
#         --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA \
#         --peerAddresses localhost:11051 --tlsRootCertFiles $PEER0_ORG3_CA \
#         --version ${VERSION} --sequence ${SEQUENCE} --init-required

# }

commitChaincodeDefination() {
    setGlobalsForPeer1ClientOrg
    peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        --channelID $CLIENT_USER_CHANNEL --name ${CC_NAME} \
        --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA \
        --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
        --version ${VERSION} --sequence ${VERSION} --init-required

        echo " commit chaincode for clientUserChannel"

    setGlobalsForPeer1UserOrg
    peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        --channelID $USER_INST_CHANNEL --name ${CC_NAME} \
        --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
        --peerAddresses localhost:12051 --tlsRootCertFiles $PEER1_INSTORG_CA \
        --version ${VERSION} --sequence ${VERSION} --init-required

        echo " commit chaincode for  userInstChannel"

    setGlobalsForPeer1InstOrg
    peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        --channelID $INST_CLIENT_CHANNEL --name ${CC_NAME} \
        --peerAddresses localhost:12051 --tlsRootCertFiles $PEER1_INSTORG_CA \
        --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA  \
        --version ${VERSION} --sequence ${VERSION} --init-required

        echo " commit chaincode for instClientChannel"

}

# commitChaincodeDefination

queryCommitted() {

    setGlobalsForPeer1UserOrg
    peer lifecycle chaincode querycommitted --channelID $USER_INST_CHANNEL --name ${CC_NAME}

    setGlobalsForPeer1ClientOrg
    peer lifecycle chaincode querycommitted --channelID $CLIENT_USER_CHANNEL --name ${CC_NAME}

    setGlobalsForPeer1InstOrg
    peer lifecycle chaincode querycommitted --channelID $INST_CLIENT_CHANNEL --name ${CC_NAME}

}


# queryCommitted

chaincodeInvokeInit() {
    setGlobalsForPeer1ClientOrg
    peer chaincode invoke -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        -C $CLIENT_USER_CHANNEL -n userprofile \
        --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA \
        --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
        --isInit -c '{"Args":[""]}'

    setGlobalsForPeer1UserOrg
    peer chaincode invoke -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com \
        --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
        -C $USER_INST_CHANNEL -n userprofile \
        --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
        --peerAddresses localhost:12051 --tlsRootCertFiles $PEER1_INSTORG_CA \
        --isInit -c '{"Args":[]}'


    # setGlobalsForPeer1InstOrg
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer.example.com \
    #     --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA \
    #     -C $INST_CLIENT_CHANNEL -n ${CC_NAME} \
    #     --peerAddresses localhost:12051 --tlsRootCertFiles $PEER1_INSTORG_CA \
    #     --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA \
    #     --isInit -c '{"Args":[]}'
}


# chaincodeInvokeInit

chaincodeInvoke() {
    # setGlobalsForPeer0Org1
    # peer chaincode invoke -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com \
    # --tls $CORE_PEER_TLS_ENABLED --cafile $ORDERER_CA -C $CHANNEL_NAME -n ${CC_NAME} \
    # --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA \
    # --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA  \
    # -c '{"function":"initLedger","Args":[]}'

    setGlobalsForPeer1ClientOrg

    ## Create Car
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer.example.com \
    #     --tls $CORE_PEER_TLS_ENABLED \
    #     --cafile $ORDERER_CA \
    #     -C $CHANNEL_NAME -n ${CC_NAME}  \
    #     --peerAddresses localhost:7051 \
    #     --tlsRootCertFiles $PEER0_ORG1_CA \
    #     --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA   \
    #     -c '{"function": "createCar","Args":["Car-ABCDEEE", "Audi", "R8", "Red", "Pavan"]}'
    setGlobalsForPeer1ClientOrg
    ## Init ledger
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer.example.com \
    #     --tls $CORE_PEER_TLS_ENABLED \
    #     --cafile $ORDERER_CA \
    #     -C $CLIENT_USER_CHANNEL -n ${CC_NAME} \
    #     --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA \
    #     --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
    #     -c '{"function": "initLedger","Args":[]}'

    # peer chaincode invoke -o localhost:7050 \
    # --ordererTLSHostnameOverride orderer.example.com \
    # --tls $CORE_PEER_TLS_ENABLED \
    # --cafile $ORDERER_CA \
    # -C $CLIENT_USER_CHANNEL -n ${CC_NAME} \
    # --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA \
    # --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
    # -c '{"function": "InitFlanitPlus", "Args":[]}'

# peer chaincode invoke -o localhost:7050 \
#     --ordererTLSHostnameOverride orderer.example.com \
#     --tls --cafile $ORDERER_CA \
#     -C $CLIENT_USER_CHANNEL \
#     -n flanitplus \
#     --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA \
#     --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
#     -c '{"function":"SaveFlanitPlus","Args":["34dksfjskd3993939" , "{\"clientId\":\"428b9d74-eebd-42d4-adba-c007dc2425af\",\"userId\":\"c3837ed9-1aa3-40bd-a344-af43b4c673bi\",\"section\":\"goalBasedPlanning\",\"goalBasedPlanning\":{\"shortTermGoal\":[{\"nameOfTheGoal\":\"Buying Car\",\"expectedAmount\":\"1212121\",\"year\":\"2023\"},{\"nameOfTheGoal\":\"Buying House\",\"expectedAmount\":\"2500000\",\"year\":\"2025\"}],\"longTermGoal\":[{\"nameOfTheGoal\":\"Retirement\",\"expectedAmount\":\"5000000\",\"year\":\"2040\"}]}}"]}'

peer chaincode invoke -o localhost:7050 \
  --ordererTLSHostnameOverride orderer.example.com \
  --tls --cafile $ORDERER_CA \
  -C $CLIENT_USER_CHANNEL \
  -n userprofile \
  --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA \
  --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
  -c '{"function":"SaveUserProfile","Args":["9f97be-sdsd-227-4510-8604-46f673663d26", "{\"userId\":\"9f97be-sdsd-227-4510-8604-46f673663d26\",\"basicDetails\":{\"fullName\":\"Prem Kumar\",\"emailAddress\":\"dfkl\",\"age\":\"dsjfl\",\"city\":\"dslfj\",\"phoneNumber\":\"ldsflk\",\"noOfClient\":\"dskfl\",\"noOfYearsExperience\":\"kjdsjf\",\"experienceExplanation\":\"lkdsfl\",\"serviceOffering\":[\"dslf\"],\"conflictOfInterest\":\"ldflk\",\"description\":\"dkfjaldkf\"}}"]}'



    # setGlobalsForPeer1UserOrg
    # ## Init ledger
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer.example.com \
    #     --tls $CORE_PEER_TLS_ENABLED \
    #     --cafile $ORDERER_CA \
    #     -C $USER_INST_CHANNEL -n ${CC_NAME} \
    #     --peerAddresses localhost:10051 --tlsRootCertFiles $PEER1_USERORG_CA \
    #     --peerAddresses localhost:12051 --tlsRootCertFiles $PEER1_INSTORG_CA \
    #     -c '{"function": "initLedger","Args":[]}'


    # setGlobalsForPeer1InstOrg
    # ## Init ledger
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer.example.com \
    #     --tls $CORE_PEER_TLS_ENABLED \
    #     --cafile $ORDERER_CA \
    #     -C $INST_CLIENT_CHANNEL -n ${CC_NAME} \
    #     --peerAddresses localhost:12051 --tlsRootCertFiles $PEER1_INSTORG_CA \
    #     --peerAddresses localhost:8051 --tlsRootCertFiles $PEER1_CLIENTORG_CA \
    #     -c '{"function": "initLedger","Args":[]}'


    ## Add private data
    # export CAR=$(echo -n "{\"key\":\"1111\", \"make\":\"Tesla\",\"model\":\"Tesla A1\",\"color\":\"White\",\"owner\":\"pavan\",\"price\":\"10000\"}" | base64 | tr -d \\n)
    # peer chaincode invoke -o localhost:7050 \
    #     --ordererTLSHostnameOverride orderer.example.com \
    #     --tls $CORE_PEER_TLS_ENABLED \
    #     --cafile $ORDERER_CA \
    #     -C $CHANNEL_NAME -n ${CC_NAME} \
    #     --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA \
    #     --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA \
    #     -c '{"function": "createPrivateCar", "Args":[]}' \
    #     --transient "{\"car\":\"$CAR\"}"
}

# chaincodeInvoke

chaincodeInvokeDeleteAsset() {
    setGlobalsForPeer0UserOrg

    # Create Car
    peer chaincode invoke -o localhost:7050 \
        --ordererTLSHostnameOverride orderer.example.com \
        --tls $CORE_PEER_TLS_ENABLED \
        --cafile $ORDERER_CA \
        -C $CHANNEL_NAME -n ${CC_NAME}  \
        --peerAddresses localhost:7051 --tlsRootCertFiles $PEER0_ORG1_CA \
        --peerAddresses localhost:9051 --tlsRootCertFiles $PEER0_ORG2_CA   \
        -c '{"function": "DeleteCarById","Args":["2"]}'

}

# chaincodeInvokeDeleteAsset

# chaincodeQuery() {
#     setGlobalsForPeer0UserOrg
#     # setGlobalsForUserOrg
#     peer chaincode query -C $CHANNEL_NAME -n ${CC_NAME} -c '{"function": "GetCarById","Args":["1"]}'
# }

chaincodeQuery() {
    setGlobalsForPeer1ClientOrg

    # Query all cars
    # peer chaincode query -C $CHANNEL_NAME -n ${CC_NAME} -c '{"Args":["queryAllCars"]}'
    peer chaincode query \
    -C $CLIENT_USER_CHANNEL \
    -n ${CC_NAME} \
    -c '{"function":"FetchUserProfile","Args":["{\"userId\":\"9f97be-sdsd-227-4510-8604-46f673663d26\"}"]}'
    # Query Car by Id
    # peer chaincode query -C $CLIENT_USER_CHANNEL -n ${CC_NAME} -c '{"function": "FetchPlanDetails","Args":["User1"]}'
    # setGlobalsForPeer1UserOrg
    # peer chaincode query -C $USER_INST_CHANNEL -n ${CC_NAME} -c '{"function": "FetchUser","Args":["User0"]}'
    # setGlobalsForPeer1InstOrg
    # peer chaincode query -C $INST_CLIENT_CHANNEL -n ${CC_NAME} -c '{"function": "FetchUser","Args":["User0"]}'
    #'{"Args":["GetSampleData","Key1"]}'

    # Query Private Car by Id
    # peer chaincode query -C $CHANNEL_NAME -n ${CC_NAME} -c '{"function": "readPrivateCar","Args":["1111"]}'
    # peer chaincode query -C $CHANNEL_NAME -n ${CC_NAME} -c '{"function": "readCarPrivateDetails","Args":["1111"]}'
}

# chaincodeQuery

# Run this function if you add any new dependency in chaincode
# presetup
# packageChaincode
# installChaincode
# queryInstalled
# approveForMyOrgforClientUserChannel
# approveForMyOrgforUserInstChannel
# approveForMyOrgforInstClientChannel
# checkCommitReadyness
# commitChaincodeDefination
# queryCommitted
# chaincodeInvokeInit
# sleep 5
# chaincodeInvoke
# sleep 3
chaincodeQuery


# # checkCommitReadyness
# # approveForMyInstOrg
# # checkCommitReadyness
# # approveForMyClientOrg
# # checkCommitReadyness