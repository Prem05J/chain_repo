createcertificatesForUserOrg() {
  # echo
  # echo "reenroll the CA admin"
  # echo
  # mkdir -p ../crypto-config_1/peerOrganizations/userOrg.example.com/
  # export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/

  # fabric-ca-client reenroll -u https://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com  --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-userOrg-example-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-userOrg-example-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-userOrg-example-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-userOrg-example-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/msp/config.yaml

  # mkdir -p ../crypto-config_1/peerOrganizations/userOrg.example.com/peers

  # # -----------------------------------------------------------------------------------
  # #  Peer 0
  # mkdir -p ../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com

  echo
  echo "## Generate the peer0 msp"
  echo
  fabric-ca-client reenroll -u https://peer0:peer0pw@localhost:7054 \
  --caname ca.userOrg.example.com -d \
  -M ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/msp \
  --csr.hosts peer0.userOrg.example.com --csr.keyrequest.reusekey \
  --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  fabric-ca-client reenroll -d --enrollment.profile tls -u https://orderer1.struatwalamo-net:orderer1.struatwalamo-net-pw@ca.struatwalamo-net:7054 -M ~/ca-tools/struatwalamo/cas/orderers/tls/orderer1.struatwalamo-net --csr.hosts orderer1.struatwalamo-net,orderer1.struatwalamo-net.prod-1.wbp.in.wal-mart.com --tls.certfiles /crypto-config/ordererOrganizations/struatwalamo-net/msp/tlscacerts/ca-struatwalamo-net-prod-1.wbp.in.wal-mart.com-8443.pem --csr.names O=struatwalamo,OU=struatwalamo,L=51.50/-0.13/Arkansas,C=US --csr.keyrequest.reusekey

  cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/msp/config.yaml ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/msp/config.yaml

  echo
  echo "## Generate the peer0-tls certificates"
  echo
  fabric-ca-client reenroll -u https://peer0:peer0pw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls --enrollment.profile tls --csr.hosts peer0.userOrg.example.com --csr.hosts localhost  --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/signcerts/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/server.crt
  cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/keystore/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/server.key

  echo
  echo "## Generate the user msp"
  echo
  fabric-ca-client reenroll -u https://user1:user1pw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/users/User1@userOrg.example.com/msp  --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  mkdir -p ../crypto-config_1/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com

  echo
  echo "## Generate the org admin msp"
  echo
  fabric-ca-client reenroll -u https://userOrgadmin:userOrgadminpw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp  --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/msp/config.yaml ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp/config.yaml

}

# createcertificatesForUserOrg

createCertificatesForInstOrg() {
  echo
  echo "reenroll the CA admin" --csr.keyrequest.reusekey
  echo
  mkdir -p /../crypto-config_1/peerOrganizations/instOrg.example.com/

  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/

  fabric-ca-client reenroll -u https://admin:adminpw@localhost:8054 --caname ca.instOrg.example.com \
   --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem \
   --csr.keyrequest.reusekey \
   --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-instOrg-example-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-instOrg-example-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-instOrg-example-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-instOrg-example-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/msp/config.yaml

  # --------------------------------------------------------------
  # Peer 0
  echo
  echo "## Generate the peer0 msp"
  echo

  fabric-ca-client reenroll -u https://peer0:peer0pw@localhost:8054 --caname ca.instOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/msp --csr.hosts peer0.instOrg.example.com --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/msp/config.yaml ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/msp/config.yaml

  echo
  echo "## Generate the peer0-tls certificates"
  echo

  fabric-ca-client reenroll -u https://peer0:peer0pw@localhost:8054 --caname ca.instOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls --enrollment.profile tls --csr.hosts peer0.instOrg.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/signcerts/* ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/server.crt
  cp ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/keystore/* ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/server.key

  echo
  echo "## Generate the user msp"
  echo

  fabric-ca-client reenroll -u https://user1:user1pw@localhost:8054 --caname ca.instOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/users/User1@instOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  mkdir -p ../crypto-config_1/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com

  echo
  echo "## Generate the org admin msp"
  echo

  fabric-ca-client reenroll -u https://instOrgadmin:instOrgadminpw@localhost:8054 --caname ca.instOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/msp/config.yaml ${PWD}/../crypto-config_1/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp/config.yaml

}

# createCertificateForInstOrg

createCertificatesForClientOrg() {
  echo
  echo "reenroll the CA admin" --csr.keyrequest.reusekey
  echo
  mkdir -p ../crypto-config_1/peerOrganizations/clientOrg.example.com/

  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/

  fabric-ca-client reenroll -u https://admin:adminpw@localhost:10054 --caname ca.clientOrg.example.com --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-clientOrg-example-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-clientOrg-example-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-clientOrg-example-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-clientOrg-example-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/msp/config.yaml

  # --------------------------------------------------------------
  # Peer 0
  echo
  echo "## Generate the peer0 msp"
  echo

  fabric-ca-client reenroll -u https://peer0:peer0pw@localhost:10054 --caname ca.clientOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/msp --csr.hosts peer0.clientOrg.example.com --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/msp/config.yaml ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/msp/config.yaml

  echo
  echo "## Generate the peer0-tls certificates"
  echo

  fabric-ca-client reenroll -u https://peer0:peer0pw@localhost:10054 --caname ca.clientOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls --enrollment.profile tls --csr.hosts peer0.clientOrg.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/signcerts/* ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/server.crt
  cp ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/keystore/* ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/server.key

  mkdir -p ../crypto-config_1/peerOrganizations/clientOrg.example.com/users
  mkdir -p ../crypto-config_1/peerOrganizations/clientOrg.example.com/users/User1@clientOrg.example.com

  echo
  echo "## Generate the user msp"
  echo

  fabric-ca-client reenroll -u https://user1:user1pw@localhost:10054 --caname ca.clientOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/users/User1@clientOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  mkdir -p ../crypto-config_1/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com

  echo
  echo "## Generate the org admin msp"
  echo

  fabric-ca-client reenroll -u https://clientOrgadmin:clientOrgadminpw@localhost:10054 --caname ca.clientOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/msp/config.yaml ${PWD}/../crypto-config_1/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp/config.yaml

}

createCretificatesForOrderer() {
  echo
  echo "reenroll the CA admin" --csr.keyrequest.reusekey
  echo
  mkdir -p ../crypto-config_1/ordererOrganizations/example.com

  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config_1/ordererOrganizations/example.com

  fabric-ca-client reenroll -u https://admin:adminpw@localhost:9054 --caname ca-orderer --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-orderer.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-orderer.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-orderer.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-orderer.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config_1/ordererOrganizations/example.com/msp/config.yaml

  # ---------------------------------------------------------------------------
  #  Orderer

  echo
  echo "## Generate the orderer msp"
  echo

  fabric-ca-client reenroll -u https://orderer:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/msp --csr.hosts orderer.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/msp/config.yaml ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo

  fabric-ca-client reenroll -u https://orderer:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/tls --enrollment.profile tls --csr.hosts orderer.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/tls/signcerts/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/tls/server.crt
  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/tls/keystore/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer.example.com/tls/server.key

  # -----------------------------------------------------------------
  #  Orderer 2

  mkdir -p ../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com

  echo
  echo "## Generate the orderer msp"
  echo

  fabric-ca-client reenroll -u https://orderer2:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/msp --csr.hosts orderer2.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/msp/config.yaml ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo

  fabric-ca-client reenroll -u https://orderer2:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/tls --enrollment.profile tls --csr.hosts orderer2.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/signcerts/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/server.crt
  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/keystore/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/server.key

  # ---------------------------------------------------------------------------
  #  Orderer 3
  mkdir -p ../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com

  echo
  echo "## Generate the orderer msp"
  echo

  fabric-ca-client reenroll -u https://orderer3:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/msp --csr.hosts orderer3.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/msp/config.yaml ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo

  fabric-ca-client reenroll -u https://orderer3:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/tls --enrollment.profile tls --csr.hosts orderer3.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/signcerts/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/server.crt
  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/keystore/* ${PWD}/../crypto-config_1/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/server.key

  echo
  echo "## Generate the admin msp"
  echo

  fabric-ca-client reenroll -u https://ordererAdmin:ordererAdminpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config_1/ordererOrganizations/example.com/users/Admin@example.com/msp --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem --csr.keyrequest.reusekey --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config_1/ordererOrganizations/example.com/msp/config.yaml ${PWD}/../crypto-config_1/ordererOrganizations/example.com/users/Admin@example.com/msp/config.yaml

}

# createCretificateForOrderer

createcertificatesForUserOrg
createCertificatesForInstOrg
createCertificatesForClientOrg

createCretificatesForOrderer
