createcertificatesForUserOrg() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p ../crypto-config/peerOrganizations/userOrg.example.com/
  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/

   
  fabric-ca-client enroll -u https://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem
   

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-userOrg-example-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-userOrg-example-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-userOrg-example-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-7054-ca-userOrg-example-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/msp/config.yaml

  echo
  echo "Register peer0"
  echo
  fabric-ca-client register --caname ca.userOrg.example.com --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  echo
  echo "Register user"
  echo
  fabric-ca-client register --caname ca.userOrg.example.com --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  echo
  echo "Register the org admin"
  echo
  fabric-ca-client register --caname ca.userOrg.example.com --id.name userOrgadmin --id.secret userOrgadminpw --id.type admin --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  mkdir -p ../crypto-config/peerOrganizations/userOrg.example.com/peers

  # -----------------------------------------------------------------------------------
  #  Peer 0
  mkdir -p ../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com

  echo
  echo "## Generate the peer0 msp"
  echo
  fabric-ca-client enroll -u https://peer0:peer0pw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/msp --csr.hosts peer0.userOrg.example.com --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/msp/config.yaml

  echo
  echo "## Generate the peer0-tls certificates"
  echo
  fabric-ca-client enroll -u https://peer0:peer0pw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls --enrollment.profile tls --csr.hosts peer0.userOrg.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/signcerts/* ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/server.crt
  cp ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/keystore/* ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/server.key

  mkdir ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/msp/tlscacerts
  cp ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/msp/tlscacerts/ca.crt

  mkdir ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/tlsca
  cp ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/tlsca/tlsca.userOrg.example.com-cert.pem

  mkdir ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/ca
  cp ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/msp/cacerts/* ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/ca/ca.userOrg.example.com-cert.pem

  # --------------------------------------------------------------------------------------------------

  mkdir -p ../crypto-config/peerOrganizations/userOrg.example.com/users
  mkdir -p ../crypto-config/peerOrganizations/userOrg.example.com/users/User1@userOrg.example.com

  echo
  echo "## Generate the user msp"
  echo
  fabric-ca-client enroll -u https://user1:user1pw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/users/User1@userOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  mkdir -p ../crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com

  echo
  echo "## Generate the org admin msp"
  echo
  fabric-ca-client enroll -u https://userOrgadmin:userOrgadminpw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

  cp ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/userOrg.example.com/users/Admin@userOrg.example.com/msp/config.yaml

}

# createcertificatesForUserOrg

createCertificatesForInstOrg() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p /../crypto-config/peerOrganizations/instOrg.example.com/

  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/

   
  fabric-ca-client enroll -u https://admin:adminpw@localhost:8054 --caname ca.instOrg.example.com --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem
   

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-instOrg-example-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-instOrg-example-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-instOrg-example-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-8054-ca-instOrg-example-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/msp/config.yaml

  echo
  echo "Register peer0"
  echo
   
  fabric-ca-client register --caname ca.instOrg.example.com --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem
   

  echo
  echo "Register user"
  echo
   
  fabric-ca-client register --caname ca.instOrg.example.com --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem
   

  echo
  echo "Register the org admin"
  echo
   
  fabric-ca-client register --caname ca.instOrg.example.com --id.name instOrgadmin --id.secret instOrgadminpw --id.type admin --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem
   

  mkdir -p ../crypto-config/peerOrganizations/instOrg.example.com/peers
  mkdir -p ../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com

  # --------------------------------------------------------------
  # Peer 0
  echo
  echo "## Generate the peer0 msp"
  echo
   
  fabric-ca-client enroll -u https://peer0:peer0pw@localhost:8054 --caname ca.instOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/msp --csr.hosts peer0.instOrg.example.com --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/msp/config.yaml

  echo
  echo "## Generate the peer0-tls certificates"
  echo
   
  fabric-ca-client enroll -u https://peer0:peer0pw@localhost:8054 --caname ca.instOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls --enrollment.profile tls --csr.hosts peer0.instOrg.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/signcerts/* ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/server.crt
  cp ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/keystore/* ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/server.key

  mkdir ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/msp/tlscacerts
  cp ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/msp/tlscacerts/ca.crt

  mkdir ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/tlsca
  cp ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/tlsca/tlsca.instOrg.example.com-cert.pem

  mkdir ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/ca
  cp ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/peers/peer0.instOrg.example.com/msp/cacerts/* ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/ca/ca.instOrg.example.com-cert.pem

  # --------------------------------------------------------------------------------
 
  mkdir -p ../crypto-config/peerOrganizations/instOrg.example.com/users
  mkdir -p ../crypto-config/peerOrganizations/instOrg.example.com/users/User1@instOrg.example.com

  echo
  echo "## Generate the user msp"
  echo
   
  fabric-ca-client enroll -u https://user1:user1pw@localhost:8054 --caname ca.instOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/users/User1@instOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem
   

  mkdir -p ../crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com

  echo
  echo "## Generate the org admin msp"
  echo
   
  fabric-ca-client enroll -u https://instOrgadmin:instOrgadminpw@localhost:8054 --caname ca.instOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/instOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/instOrg.example.com/users/Admin@instOrg.example.com/msp/config.yaml

}

# createCertificateForInstOrg

createCertificatesForClientOrg() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p ../crypto-config/peerOrganizations/clientOrg.example.com/

  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/

   
  fabric-ca-client enroll -u https://admin:adminpw@localhost:10054 --caname ca.clientOrg.example.com --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem
   

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-clientOrg-example-com.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-clientOrg-example-com.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-clientOrg-example-com.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-10054-ca-clientOrg-example-com.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/msp/config.yaml

  echo
  echo "Register peer0"
  echo
   
  fabric-ca-client register --caname ca.clientOrg.example.com --id.name peer0 --id.secret peer0pw --id.type peer --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem
   

  echo
  echo "Register user"
  echo
   
  fabric-ca-client register --caname ca.clientOrg.example.com --id.name user1 --id.secret user1pw --id.type client --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem
   

  echo
  echo "Register the org admin"
  echo
   
  fabric-ca-client register --caname ca.clientOrg.example.com --id.name clientOrgadmin --id.secret clientOrgadminpw --id.type admin --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem
   

  mkdir -p ../crypto-config/peerOrganizations/clientOrg.example.com/peers
  mkdir -p ../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com

  # --------------------------------------------------------------
  # Peer 0
  echo
  echo "## Generate the peer0 msp"
  echo
   
  fabric-ca-client enroll -u https://peer0:peer0pw@localhost:10054 --caname ca.clientOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/msp --csr.hosts peer0.clientOrg.example.com --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/msp/config.yaml

  echo
  echo "## Generate the peer0-tls certificates"
  echo
   
  fabric-ca-client enroll -u https://peer0:peer0pw@localhost:10054 --caname ca.clientOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls --enrollment.profile tls --csr.hosts peer0.clientOrg.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/signcerts/* ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/server.crt
  cp ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/keystore/* ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/server.key

  mkdir ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/msp/tlscacerts
  cp ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/msp/tlscacerts/ca.crt

  mkdir ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/tlsca
  cp ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/tlsca/tlsca.clientOrg.example.com-cert.pem

  mkdir ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/ca
  cp ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/peers/peer0.clientOrg.example.com/msp/cacerts/* ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/ca/ca.clientOrg.example.com-cert.pem

  # --------------------------------------------------------------------------------

  mkdir -p ../crypto-config/peerOrganizations/clientOrg.example.com/users
  mkdir -p ../crypto-config/peerOrganizations/clientOrg.example.com/users/User1@clientOrg.example.com

  echo
  echo "## Generate the user msp"
  echo
   
  fabric-ca-client enroll -u https://user1:user1pw@localhost:10054 --caname ca.clientOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/users/User1@clientOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem
   

  mkdir -p ../crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com

  echo
  echo "## Generate the org admin msp"
  echo
   
  fabric-ca-client enroll -u https://clientOrgadmin:clientOrgadminpw@localhost:10054 --caname ca.clientOrg.example.com -M ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp --tls.certfiles ${PWD}/fabric-ca/clientOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/msp/config.yaml ${PWD}/../crypto-config/peerOrganizations/clientOrg.example.com/users/Admin@clientOrg.example.com/msp/config.yaml

}

createCretificatesForOrderer() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p ../crypto-config/ordererOrganizations/example.com

  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config/ordererOrganizations/example.com

   
  fabric-ca-client enroll -u https://admin:adminpw@localhost:9054 --caname ca-orderer --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  echo 'NodeOUs:
  Enable: true
  ClientOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-orderer.pem
    OrganizationalUnitIdentifier: client
  PeerOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-orderer.pem
    OrganizationalUnitIdentifier: peer
  AdminOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-orderer.pem
    OrganizationalUnitIdentifier: admin
  OrdererOUIdentifier:
    Certificate: cacerts/localhost-9054-ca-orderer.pem
    OrganizationalUnitIdentifier: orderer' >${PWD}/../crypto-config/ordererOrganizations/example.com/msp/config.yaml

  echo
  echo "Register orderer"
  echo
   
  fabric-ca-client register --caname ca-orderer --id.name orderer --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  echo
  echo "Register orderer2"
  echo
   
  fabric-ca-client register --caname ca-orderer --id.name orderer2 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  echo
  echo "Register orderer3"
  echo
   
  fabric-ca-client register --caname ca-orderer --id.name orderer3 --id.secret ordererpw --id.type orderer --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  echo
  echo "Register the orderer admin"
  echo
   
  fabric-ca-client register --caname ca-orderer --id.name ordererAdmin --id.secret ordererAdminpw --id.type admin --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  mkdir -p ../crypto-config/ordererOrganizations/example.com/orderers
  # mkdir -p ../crypto-config/ordererOrganizations/example.com/orderers/example.com

  # ---------------------------------------------------------------------------
  #  Orderer

  mkdir -p ../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com

  echo
  echo "## Generate the orderer msp"
  echo
   
  fabric-ca-client enroll -u https://orderer:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp --csr.hosts orderer.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/config.yaml ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo
   
  fabric-ca-client enroll -u https://orderer:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls --enrollment.profile tls --csr.hosts orderer.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/signcerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/server.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/keystore/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/server.key

  mkdir ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  mkdir ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/tlscacerts
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  # -----------------------------------------------------------------------
  #  Orderer 2

  mkdir -p ../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com

  echo
  echo "## Generate the orderer msp"
  echo
   
  fabric-ca-client enroll -u https://orderer2:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/msp --csr.hosts orderer2.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/config.yaml ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo
   
  fabric-ca-client enroll -u https://orderer2:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls --enrollment.profile tls --csr.hosts orderer2.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/signcerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/server.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/keystore/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/server.key

  mkdir ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/msp/tlscacerts
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  # mkdir ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/tlscacerts
  # cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer2.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  # ---------------------------------------------------------------------------
  #  Orderer 3
  mkdir -p ../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com

  echo
  echo "## Generate the orderer msp"
  echo
   
  fabric-ca-client enroll -u https://orderer3:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/msp --csr.hosts orderer3.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/config.yaml ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/msp/config.yaml

  echo
  echo "## Generate the orderer-tls certificates"
  echo
   
  fabric-ca-client enroll -u https://orderer3:ordererpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls --enrollment.profile tls --csr.hosts orderer3.example.com --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/ca.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/signcerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/server.crt
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/keystore/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/server.key

  mkdir ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/msp/tlscacerts
  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  # mkdir ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/tlscacerts
  # cp ${PWD}/../crypto-config/ordererOrganizations/example.com/orderers/orderer3.example.com/tls/tlscacerts/* ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/tlscacerts/tlsca.example.com-cert.pem

  # ---------------------------------------------------------------------------

  mkdir -p ../crypto-config/ordererOrganizations/example.com/users
  mkdir -p ../crypto-config/ordererOrganizations/example.com/users/Admin@example.com

  echo
  echo "## Generate the admin msp"
  echo
   
  fabric-ca-client enroll -u https://ordererAdmin:ordererAdminpw@localhost:9054 --caname ca-orderer -M ${PWD}/../crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp --tls.certfiles ${PWD}/fabric-ca/ordererOrg/tls-cert.pem
   

  cp ${PWD}/../crypto-config/ordererOrganizations/example.com/msp/config.yaml ${PWD}/../crypto-config/ordererOrganizations/example.com/users/Admin@example.com/msp/config.yaml

}

# createCretificateForOrderer

sudo rm -rf ../crypto-config/*
# sudo rm -rf fabric-ca/*
createcertificatesForUserOrg
createCertificatesForInstOrg
createCertificatesForClientOrg

createCretificatesForOrderer

