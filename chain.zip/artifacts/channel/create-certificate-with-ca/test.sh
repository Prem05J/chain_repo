createcertificatesForUserOrg() {
  echo
  echo "Enroll the CA admin"
  echo
  mkdir -p ../crypto-config_1/peerOrganizations/userOrg.example.com/
  export FABRIC_CA_CLIENT_HOME=${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/

   
  fabric-ca-client enroll -u http://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com 
#   --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem
   

  # -----------------------------------------------------------------------------------
  #  Peer 0
  mkdir -p ../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com

  echo
  echo "## Generate the peer0-tls certificates"
  echo
  fabric-ca-client enroll -u http://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls --enrollment.profile tls --csr.hosts peer0.userOrg.example.com --csr.hosts localhost 
#   --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem

#   cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/ca.crt
#   cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/signcerts/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/server.crt
#   cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/keystore/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/server.key

#   mkdir ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/msp/tlscacerts
#   cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/msp/tlscacerts/ca.crt

#   mkdir ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/tlsca
#   cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/tls/tlscacerts/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/tlsca/tlsca.userOrg.example.com-cert.pem

#   mkdir ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/ca
#   cp ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/peers/peer0.userOrg.example.com/msp/cacerts/* ${PWD}/../crypto-config_1/peerOrganizations/userOrg.example.com/ca/ca.userOrg.example.com-cert.pem

}

createcertificatesForUserOrg
