
# # Delete existing artifacts
# rm genesis.block mychannel.tx
# rm -rf ../../channel-artifacts/*

# #Generate Crypto artifactes for organizations
# cryptogen generate --config=./crypto-config.yaml --output=./crypto-config/



# # System channel
# SYS_CHANNEL="sys-channel"

# # channel name defaults to "mychannel"
# CHANNEL_NAME="mychannel"

# echo $CHANNEL_NAME

# # Generate System Genesis block
# configtxgen -profile OrdererGenesis -configPath . -channelID $SYS_CHANNEL  -outputBlock ./genesis.block


# # Generate channel configuration block
# configtxgen -profile BasicChannel -configPath . -outputCreateChannelTx ./$CHANNEL_NAME.tx -channelID $CHANNEL_NAME

# echo "#######    Generating anchor peer update for UserOrgMSP  ##########"
# configtxgen -profile BasicChannel -configPath . -outputAnchorPeersUpdate ./UserOrgMSPanchors.tx -channelID $CHANNEL_NAME -asOrg UserOrgMSP

# echo "#######    Generating anchor peer update for InstOrgMSP  ##########"
# configtxgen -profile BasicChannel -configPath . -outputAnchorPeersUpdate ./InstOrgMSPanchors.tx -channelID $CHANNEL_NAME -asOrg InstOrgMSP

# echo "#######    Generating anchor peer update for ClientOrgMSP  ##########"
# configtxgen -profile BasicChannel -configPath . -outputAnchorPeersUpdate ./ClientOrgMSPanchors.tx -channelID $CHANNEL_NAME -asOrg ClientOrgMSP



# chmod -R 0755 ./crypto-config
# # Delete existing artifacts
# rm -rf ./crypto-config
# rm genesis.block mychannel.tx
# rm -rf ../../channel-artifacts/*
# rm -rf ./channels/*
# rm -rf ./anchors/*

# #Generate Crypto artifactes for organizations
# cryptogen generate --config=./crypto-config.yaml --output=./crypto-config/





# # channel name defaults to "mychannel"
# CHANNEL_NAME="mychannel"


# echo $CHANNEL_NAME


# System channel
# SYS_CHANNEL="sys-channel"
# # Generate System Genesis block
# configtxgen -profile OrdererGenesis -configPath . -channelID $SYS_CHANNEL  -outputBlock ./genesis.block


INST_CLIENT_CHANNEL="instclientchannel"
USER_INST_CHANNEL="userinstchannel"
CLIENT_USER_CHANNEL="clientuserchannel"
# # # Generate channel configuration block
# configtxgen -profile InstClientChannel -configPath . -outputCreateChannelTx ./channels/instclientchannel.tx -channelID $INST_CLIENT_CHANNEL
# configtxgen -profile UserInstChannel -configPath . -outputCreateChannelTx ./channels/userinstchannel.tx -channelID $USER_INST_CHANNEL
# configtxgen -profile ClientUserChannel -configPath . -outputCreateChannelTx ./channels/clientuserchannel.tx -channelID $CLIENT_USER_CHANNEL



# echo "#######    Generating anchor peer update for Org1MSP  ##########"
configtxgen -profile ClientUserChannel  -configPath . -outputAnchorPeersUpdate ./anchors/ClientOrgMSPanchors.tx -channelID $CLIENT_USER_CHANNEL -asOrg ClientOrgMSP

# echo "#######    Generating anchor peer update for Org1MSP  ##########"
configtxgen -profile ClientUserChannel  -configPath . -outputAnchorPeersUpdate ./anchors/UserOrgMSP1anchors.tx -channelID $CLIENT_USER_CHANNEL -asOrg UserOrgMSP

# echo "#######    Generating anchor peer update for Org2MSP  ##########"
configtxgen -profile UserInstChannel -configPath . -outputAnchorPeersUpdate ./anchors/UserOrgMSPanchors.tx -channelID $USER_INST_CHANNEL -asOrg UserOrgMSP

# echo "#######    Generating anchor peer update for Org2MSP  ##########"
configtxgen -profile UserInstChannel -configPath . -outputAnchorPeersUpdate ./anchors/InstOrgMSP1anchors.tx -channelID $USER_INST_CHANNEL -asOrg InstOrgMSP

configtxgen -profile InstClientChannel -configPath . -outputAnchorPeersUpdate ./anchors/InstOrgMSPanchors.tx -channelID $CLIENT_USER_CHANNEL -asOrg InstOrgMSP

configtxgen -profile InstClientChannel -configPath . -outputAnchorPeersUpdate ./anchors/ClientOrgMSP1anchors.tx -channelID $CLIENT_USER_CHANNEL -asOrg ClientOrgMSP