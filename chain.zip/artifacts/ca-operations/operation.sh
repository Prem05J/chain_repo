export FABRIC_CA_CLIENT_HOME=${PWD}/clients/admin

EnrollAdmin() {

    # fabric-ca-client enroll -u http://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com 
    # fabric-ca-client enroll -u https://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com --tls.certfiles ${PWD}/fabric-ca/server.crt
    fabric-ca-client enroll -u https://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
    # fabric-ca-client enroll -u https://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com --tls.certfiles ${PWD}/pavan2/tls/tlscacerts/tls-localhost-7054-ca-userOrg-example-com.pem

    # fabric-ca-client enroll -u https://admin:adminpw@localhost:7054 --caname ca.userOrg.example.com --tls.certfiles ${PWD}/pavan2/tls/server.crt

}

# EnrollAdmin



# fabric-ca-client register -u http://localhost:7054 --caname ca.userOrg.example.com --id.name fabric-ca-server2 --id.type fabric --id.secret adminpw 
# --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
# fabric-ca-client enroll -u http://fabric-ca-server2:adminpw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/./jaun/tls --enrollment.profile tls --csr.hosts ca --csr.hosts localhost 
# --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem

fabric-ca-client register -u https://localhost:7054 --caname ca.userOrg.example.com --id.name jaun --id.type fabric --id.secret adminpw --tls.certfiles ${PWD}/fabric-ca/server.crt
# fabric-ca-client enroll -u http://fabric-ca-server2:adminpw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/./jaun/tls --enrollment.profile tls --csr.hosts ca --csr.hosts localhost 
# --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem


# fabric-ca-client register --caname ca.userOrg.example.com --id.name ca --id.secret ca-password --id.type fabric --tls.certfiles ${PWD}/fabric-ca/userOrg/tls-cert.pem
# fabric-ca-client register --caname ca.userOrg.example.com --id.name abcd --id.type fabric --id.secret adminpw --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
# fabric-ca-client enroll -u https://abcd:adminpw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/./pavan2/tls --enrollment.profile tls --csr.hosts ca --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem

# fabric-ca-client register --caname ca.userOrg.example.com --id.name fabric-ca-server2 --id.type fabric --id.secret adminpw --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
# fabric-ca-client enroll -u https://fabric-ca-server2:adminpw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/./pavan3/tls --enrollment.profile tls --csr.hosts ca --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem

# fabric-ca-client register -u https://localhost:7054 --caname ca.userOrg.example.com --id.name ca3 --id.secret ca-password --id.type fabric --tls.certfiles ${PWD}/fabric-ca/server.crt
# fabric-ca-client register --caname ca.userOrg.example.com --id.name abcd --id.type fabric --id.secret adminpw --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
# fabric-ca-client enroll -u https://ca3:ca-password@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/./pavan4/tls --enrollment.profile tls --csr.hosts ca --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/server.crt

# fabric-ca-client register --caname ca.userOrg.example.com --id.name fabric-ca-server2 --id.type fabric --id.secret adminpw --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
# fabric-ca-client enroll -u https://fabric-ca-server2:adminpw@localhost:7054 --caname ca.userOrg.example.com -M ${PWD}/./pavan3/tls --enrollment.profile tls --csr.hosts ca --csr.hosts localhost --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem


RegisterNewAdmin() {
    # export FABRIC_CA_CLIENT_HOME=${PWD}/clients/admin2
    # fabric-ca-client register --id.name admin2 --id.affiliation userOrg.department1 --id.attrs 'hf.Revoker=true,admin=true:ecert'
    # fabric-ca-client register -d --id.name admin2 --id.affiliation userOrg.department1 --id.attrs '"hf.Registrar.Roles=peer,client"' --id.attrs hf.Revoker=true
    fabric-ca-client register \
        --caname ca.userOrg.example.com \
        --id.name admin3 \
        --id.type admin \
        --id.attrs 'hf.Revoker=true,admin=true:ecert' \
        --id.affiliation userOrg.department1 \
        --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
        # --id.secret admin3pw \
}

# RegisterNewAdmin


ReenrollIdentity() {



    # export FABRIC_CA_CLIENT_HOME=${PWD}/clients/peer1

    fabric-ca-client certificate list --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem


    # fabric-ca-client \
    #     reenroll \
    #     -u https://admin3:peer4pw@localhost:7054 \
    #     --caname ca.userOrg.example.com \
    #     --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
}

# ReenrollIdentity

RegisterPeer() {
    fabric-ca-client register \
        --caname ca.userOrg.example.com \
        --id.name peer4 \
        --id.secret peer4pw \
        --id.type peer \
        --id.affiliation userOrg.department1 \
        --id.attrs '"hf.Registrar.Roles=peer,client"' \
        --id.attrs hf.Revoker=true \
        --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem

    # fabric-ca-client register \
    #     --caname ca.userOrg.example.com \
    #     --id.name peer3 \
    #     --id.type peer \
    #     --id.affiliation userOrg.department1 \
    #     --id.attrs '"hf.Registrar.Roles=peer,client"' \
    #     --id.attrs hf.Revoker=true \
    #     --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem

}

# RegisterPeer

EnrollPeer() {

    fabric-ca-client enroll \
        -u https://peer4:peer4pw@localhost:7054 \
        --caname ca.userOrg.example.com \
        -M ${PWD}/clients/peer1/msp \
        --csr.hosts peer0.userOrg.example.com \
        --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
}

# EnrollPeer

ReenrollIdentity() {

    export FABRIC_CA_CLIENT_HOME=${PWD}/clients/peer1
    fabric-ca-client \
        reenroll \
        -u https://peer4:peer4pw@localhost:7054 \
        --caname ca.userOrg.example.com \
        --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
}

# ReenrollIdentity

RevokeIdentity() {
    export FABRIC_CA_CLIENT_HOME=${PWD}/clients/admin
    fabric-ca-client revoke \
        -e peer4 \
        -r keycompromise \
        --gencrl \
        --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem

}

# RevokeIdentity

GetIdentityInfo() {

    # fabric-ca-client identity list --id peer1 --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
    fabric-ca-client identity list --id peer1 --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem

}

# GetIdentityInfo

GetIdentityList() {
    fabric-ca-client identity list --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem

}

# GetIdentityList

# Add new identity with json string ot flags
AddNewIdentity() {

    fabric-ca-client identity add user1 \
        --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem \
        --json '{"secret": "user1pw", "type": "client", "affiliation": "userOrg", "max_enrollments": 1, "attrs": [{"name": "hf.Revoker", "value": "true"}]}'

    fabric-ca-client identity add user1 \
        --secret user1pw \
        --type client \
        --affiliation . \
        --maxenrollments 1 \
        --attrs hf.Revoker=true \
        --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem
}

ModifyIdentity() {

    fabric-ca-client identity modify user1 \
        --tls.certfiles ${PWD}/fabric-ca/tls-cert.pem \
        --json '{"secret": "newPassword", "affiliation": ".", "attrs": [{"name": "hf.Regisrar.Roles", "value": "peer,client"},{"name": "hf.Revoker", "value": "true"}]}'

    fabric-ca-client identity modify user1 --secret newsecret

    fabric-ca-client identity modify user1 --affiliation instOrg

    fabric-ca-client identity modify user1 --type peer

    fabric-ca-client identity modify user1 --maxenrollments 5

    # By specifying a maxenrollments value of ‘-2’, the following causes identity ‘user1’ to use the CA’s max enrollment setting.
    fabric-ca-client identity modify user1 --maxenrollments -2

    fabric-ca-client identity modify user1 --attrs hf.Revoker=false

    fabric-ca-client identity modify user1 --attrs hf.Revoker=

    fabric-ca-client identity modify user1 --secret newpass --type peer

}

RemoveIdentity() {

    fabric-ca-client identity remove user1

}

AffiliationOperations() {
    # Add
    fabric-ca-client affiliation add userOrg.dept1

    # Modify
    fabric-ca-client affiliation modify instOrg --name clientOrg

    # Remove
    fabric-ca-client affiliation remove instOrg

    # Get All Affiliation
    fabric-ca-client affiliation list

    # Get All with specific affliliation
    fabric-ca-client affiliation list --affiliation instOrg.dept1

}

CertificateList() {

    # The certificates which will be listed may be filtered based on ID, AKI, serial number, expiration time, revocation time, notrevoked, and notexpired flags.

    # id: List certificates for this enrollment ID
    # serial: List certificates that have this serial number
    # aki: List certificates that have this AKI
    # expiration: List certificates that have expiration dates that fall within this expiration time
    # revocation: List certificates that were revoked within this revocation time
    # notrevoked: List certificates that have not yet been revoked
    # notexpired: List certificates that have not yet expired

    fabric-ca-client certificate list
    fabric-ca-client certificate list --id admin
    fabric-ca-client certificate list --serial 1234 --aki 1234
    fabric-ca-client certificate list --id admin --serial 1234 --aki 1234
    fabric-ca-client certificate list --id admin --notrevoked --notexpired
    fabric-ca-client certificate list --id admin --notrevoked
    fabric-ca-client certificate list --id admin --notexpired

    # List all certificates that were revoked between a time range for an id (admin):
    fabric-ca-client certificate list --id admin --revocation 2018-01-01T01:30:00z::2018-01-30T05:00:00z
    fabric-ca-client certificate list --id admin --revocation 2018-01-01::2018-01-30 --notexpired

    # List all revoked certificates using duration (revoked between 30 days and 15 days ago) for an id (admin)
    fabric-ca-client certificate list --id admin --revocation -30d::-15d

    # fabric-ca-client certificate list --revocation ::2018-01-30
    fabric-ca-client certificate list --revocation ::2018-01-30

    # List all revoked certificates before a time
    fabric-ca-client certificate list --revocation ::2018-01-30

    # List all revoked certificates after a time
    fabric-ca-client certificate list --revocation 2018-01-30::

    # List all revoked certificates before now and after a certain da
    fabric-ca-client certificate list --id admin --revocation 2018-01-30::now

    # List all certificate that expired between a time range but have not been revoked for an id (admin):
    fabric-ca-client certificate list --id admin --expiration 2018-01-01::2018-01-30 --notrevoked

    # List all expired certificates using duration (expired between 30 days and 15 days ago) for an id (admin):
    fabric-ca-client certificate list --expiration -30d::-15d

    # List all certificates that have expired or will expire before a certain time
    fabric-ca-client certificate list --expiration ::2058-01-30

    # List all certificates that have expired or will expire after a certain time
    fabric-ca-client certificate list --expiration 2018-01-30::

    # List all expired certificates before now and after a certain date
    fabric-ca-client certificate list --expiration 2018-01-30::now

    # List certificates expiring in the next 10 days:
    fabric-ca-client certificate list --id admin --expiration ::+10d --notrevoked

}
